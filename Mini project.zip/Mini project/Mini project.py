import numpy as np
import math
sensorData = np.genfromtxt("sensor_data.csv",delimiter=',',skip_header=1,usecols=(1,2,3,4))

temp = sensorData[:,0]
dis = sensorData[:,1]
batt = sensorData[:,2]
hum = sensorData[:,3]

#temp
print("maximum temperature is",max(temp))
print("minimum temperature is",min(temp))
print("average temperature is",np.mean(temp))

print()

#dis
print("maximum distance is",max(dis))
print("minimum distance is",min(dis))
print("average distance is",np.mean(dis))

print()

#batt
print("maximum battery is",max(batt))
print("minimum battery is",min(batt))
print("average battery is",np.mean(batt))

print()

#hum
print("maximum humidity is",max(hum))
print("minimum humidity is",min(hum))
print("average humidity is",np.mean(hum))

print()

time  = np.genfromtxt("sensor_data.csv",dtype=str,delimiter=',',skip_header=1,usecols=(0))
highestTemp = np.argmax(temp)
print("temperature wax maximum at",time[highestTemp])

print()

lowBatteryIndex = batt<=30
lowBattery = batt[lowBatteryIndex]
print(lowBattery)

n = len(lowBattery)

with open("Result.csv",'w') as d:
    d.write(f"average temperature is {np.mean(temp)}\n")
    d.write(f"minimum temperature is {min(temp)}\n")
    d.write(f"average temperature is {np.mean(temp)}\n")

    d.write('\n')

    d.write(f"average distance is {np.mean(dis)}\n")
    d.write(f"minimum distance is {min(dis)}\n")
    d.write(f"average distance is {np.mean(dis)}\n")

    d.write('\n')

    d.write(f"average battery is {np.mean(batt)}\n")
    d.write(f"minimum battery is {min(batt)}\n")
    d.write(f"average battery is {np.mean(batt)}\n")

    d.write(f"average humidity is {np.mean(hum)}\n")
    d.write(f"minimum humidity is {min(hum)}\n")
    d.write(f"average humidity is {np.mean(hum)}\n")

    d.write('\n')

    d.write(f"temperature was maximum at {time[lowBatteryIndex]}\n")
    d.write(f"temperature below 30 {n} times")