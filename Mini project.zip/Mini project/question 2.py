import numpy as np

positions = np.genfromtxt("robot_path.csv",delimiter=',',skip_header=1,usecols=(0,1))

steps = np.diff(positions, axis=0)
distances = np.linalg.norm(steps, axis=1)
totalDistance = np.sum(distances)
print("Todal distance travelled by robot is",totalDistance)

distanceFromOrigin= np.linalg.norm(positions, axis=1)
farthestIndex = np.argmax(distanceFromOrigin)
farthestPoint = positions[farthestIndex]
farthestDistance = distanceFromOrigin[farthestIndex]

print("Farthest point from index is",farthestPoint)

unique_positions, counts = np.unique(positions, axis=0, return_counts=True)
revisited = unique_positions[counts > 1]
print("revisited postions are:\n")
print(revisited)
print("no of poisitons that have been revisited: ",len(revisited))

with open("robot_path!.txt", "w") as file:
    file.write(f"total distance travelled by robot is {totalDistance}\n")
    file.write(f"farthest point from index is {farthestPoint}\n")
    file.write(f"revisited positions are\n{revisited}\n")
    file.write(f"no of positions that have been reivisted are: len(revisited)")